window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition= new SpeechRecognition(); 
recognition.imterResults= true;
recognition.lang= 'en-US'; 

let p=document.createElement('p');
const words= document.querySelector('.words');
words.appendChild(p);

//taget an event "if you _ something will happen"  function called when something happens
 recognition.addEventListener('result',e => {
    const transcript = Array.from(e.results)  
        .map(result => result[0])
        .map(result => result.transcript)
        .join(''); 

        const anuScript= transcript.replace(/Anu/, '');
        p.textContent = anuScript;

        if (e.results[0].isFinal) {
            p=document.createElement('p');
            words.appendChild(p);
        }
});   
recognition.addEventListener('end' , recognition.start);
recognition.start();

// map = object hold key value pairs and remebers og method ,,, ausation order of methods

